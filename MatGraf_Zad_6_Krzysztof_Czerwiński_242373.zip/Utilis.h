//
// Created by redkc on 19/10/2023.
//

#ifndef MATGRAF__UTILIS_H
#define MATGRAF__UTILIS_H

#define M_PI 3.14159265358979323846

double radianToDegree(double radians);
double degreeToRadian(double radians);

#endif //MATGRAF__UTILIS_H
