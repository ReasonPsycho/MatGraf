#include <iostream>
#include "Vector3.h"
#include "Matrix4x4.h"
#include "Quaternion.h"
#include "Utilis.h"
#include "Line.h"
#include "Plane.h"
#include "Cube.h"
#include "Camera.h"
#include <curses.h>


/*
// Creating the boundary planes
BoundaryPlane face1(p1, p2, p3,  p1, p4); //Front

BoundaryPlane face2(p2, p4, p5,  p2, p4); //Right

BoundaryPlane face3(p1, p3, p7,  p1, p7); //Left

BoundaryPlane face4(p3, p4, p8, p3, p8); //Top

BoundaryPlane face5(p5, p6, p7, p5, p6); //Back

BoundaryPlane face6(p1, p2, p6, p8, p7); //Downawrd
*/

Vector3 p1(-1, -1, -1);  // Front bottom left
Vector3 p2(1, -1, -1);   // Front bottom right
Vector3 p3(-1, 1, -1);   // Front top left
Vector3 p4(1, 1, -1);    // Front top right

Vector3 p5(-1, -1, 1);   // Back bottom left
Vector3 p6(1, -1, 1);    // Back bottom right
Vector3 p7(-1, 1, 1);    // Back top left
Vector3 p8(1, 1, 1);     // Back top right


BoundaryPlane face1(p1, p2, p3,  p1, p4);  // Front - the rectangle edge from p1 to p4
BoundaryPlane face2(p2, p6, p4,  p2, p8);  // Right - the rectangle edge from p2 to p8
BoundaryPlane face3(p1, p5, p3,  p1, p7);  // Left - the rectangle edge from p1 to p7
BoundaryPlane face4(p3, p7, p4,  p3, p8);  // Top - the rectangle edge from p3 to p8
BoundaryPlane face5(p5, p6, p7,  p5, p8);  // Back - the rectangle edge from p5 to p8
BoundaryPlane face6(p1, p2, p5,  p1, p6);  // Bottom - the rectangle edge from p1 to p6


// Creating the cube
std::array<BoundaryPlane, 6> faces = {face1, face2, face3, face4, face5, face6};
Cube cube(faces);

int main() {
    // initialize the library
    initscr();                  // start the curses mode
    if(has_colors() == FALSE)   // check if terminal supports color
    {
        endwin();
        printf("Your terminal does not support color\n");
        return 1;
    }
    start_color();              // start color functionality
    
    init_pair(1, COLOR_WHITE, COLOR_BLACK);
    init_pair(2, COLOR_RED, COLOR_BLACK);
    init_pair(3, COLOR_GREEN, COLOR_BLACK);
    init_pair(4, COLOR_YELLOW, COLOR_BLACK);
    init_pair(5, COLOR_BLUE, COLOR_BLACK);
    init_pair(6, COLOR_MAGENTA, COLOR_BLACK);
    init_pair(7, COLOR_CYAN, COLOR_BLACK);

    /*
    init_pair(1, COLOR_WHITE, COLOR_BLACK);
    init_pair(2, COLOR_WHITE, COLOR_BLACK);
    init_pair(3, COLOR_WHITE, COLOR_BLACK);
    init_pair(4, COLOR_WHITE, COLOR_BLACK);
    init_pair(5, COLOR_WHITE, COLOR_BLACK);
    init_pair(6, COLOR_MAGENTA, COLOR_BLACK);
    init_pair(7, COLOR_CYAN, COLOR_BLACK);
     */
// Don't wait for Enter key
    nodelay(stdscr, TRUE);
// Don't show a cursor
    curs_set(FALSE);

    Vector3 cameraPosition(+2, -2, -5); // Define camera position
    Camera camera(cameraPosition); // Initialize Camera at position

    int ch;
    do {
        std::array<std::array<Line, 60>, 60> rays = camera.CastRays(); // Cast Rays
        for (int x = 0; x < 60; ++x) {
            for(int y = 0; y < 60; ++y) {
                int intersect = cube.Intersect(rays[x][y]);
                if (intersect != -1) {
                    attron(COLOR_PAIR(intersect + 2));  // activate color based on intersection value
                    mvprintw(x, y, "0");
                    attroff(COLOR_PAIR(intersect + 2)); // deactivate color
                } else {
                    mvprintw(x, y, ".");
                }
            }
        }
        // refresh the screen to see the changes
        refresh();

        ch = getch();
        switch (ch) {
            case '=':
                camera.zoom += 0.1f;
                break;
            case '-':
                camera.zoom -= 0.1f;
                break;
            case 'w':
                camera.pitch += 0.1f;
                break;
            case 's':
                camera.pitch -= 0.1f;
                break;
            case 'a':
                camera.yaw += 0.1f;
                break;
            case 'd':
                camera.yaw -= 0.1f;
                break;
            case 'x':
                camera.roll += 0.1f;
                break;
            case 'c':
                camera.roll -= 0.1f;
                break;
            default:
                break;
        }

    } while (ch != 27); // 27 is the ASCII code for ESC

// free resources and return to normal terminal mode
    endwin();
    return 0;
}
