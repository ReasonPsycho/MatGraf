//
// Created by redkc on 21/12/2023.
//

#ifndef MATGRAF__SPHERE_H
#define MATGRAF__SPHERE_H


#include "Vector3.h"

class Sphere {
public:
    Vector3 centerPoint;
    float radius;
};


#endif //MATGRAF__SPHERE_H
